def welcome():
  print("Hey you are welcome from harry")

# print(__name__)

if __name__ == "__main__":
  welcome()