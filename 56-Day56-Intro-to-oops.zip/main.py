def hello():
  print("hello")

hello()
sales1 = 6000
profit1 = 2000
ad1 = 1000
# rajeev.sales

sales2 = 6000
profit2 = 2000
ad2 = 1000 
# vikrant.sales

sales3 = 6000
profit3 = 2000
ad3 = 1000
 
RailwayForm   ---> Class [blueprint]
harry --> harry ki info wala form --> Object [entity]
tom --> tom ki info wala form --> Object [entity]
shubham -- shubham ki info wala form --> Object [entity]
# shubham.changeName("Shubhi")
