# Access Specifiers/Modifiers
Access specifiers or access modifiers in python programming are used to limit the access of class variables and class methods outside of class while implementing the concepts of inheritance.

Let us see the each one of access specifiers in detail:
# Types of access specifiers 
1.  Public access modifier
2. Private access modifier
3. Protected access modifier
   