# Exercise 10
Use the NewsAPI and the requests module to fetch the daily news related to different topics. 
Go to: https://newsapi.org/
and explore the various options to build you application